============
SDL Renderer
============

API
***

:ref:`lv_draw_sdl_h`

