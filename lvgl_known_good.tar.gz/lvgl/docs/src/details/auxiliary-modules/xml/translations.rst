.. _xml_translations:

============
Translations
============

TODO
